// cibles.js
const TARGET_WIDTH = 40;
const TARGET_HEIGHT = 40;


