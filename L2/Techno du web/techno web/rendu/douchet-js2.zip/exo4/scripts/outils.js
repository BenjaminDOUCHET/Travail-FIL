const alea =function(n){
  return parseInt(Math.random()*n)
}



const nbocc= function(l , e){
  res=0
  for(let elem of l ){
    (if elem === e){res++}
  }
}
