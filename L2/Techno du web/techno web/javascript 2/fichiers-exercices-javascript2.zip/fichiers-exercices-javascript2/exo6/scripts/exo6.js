// script exo6.js pour exercice "Conversion de températures"
