// script exo5.js pour exercice "Boutons et click"
