BDD2 TP1 , COLLE Maxime , DOUCHET Benjamin.

Exercice 1 :

c) on peut se dire qu'il n'y a pas besoin de matérialiser le rang car on peut trier les temps
dans la BDD .
cependant pour faciliter une recherche par rang il  est intéressant de formaliser le rang.



Exercice 2 :

Si l'on veut s'assurer de la cohérence des ingrédients Etape vs Recette, on peut comparer
l'association ingrédient-Qte de recette par rapport à ingredient- somme des quantité des étapes 

On peut raisonner de la même manière pour les temps de réalisation Globale et par étape.