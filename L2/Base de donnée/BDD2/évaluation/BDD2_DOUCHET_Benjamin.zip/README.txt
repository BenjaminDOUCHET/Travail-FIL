DOUCHET Benjamin

Bonjour , 

pour résumer les choix que j'ai effectués.

Le schema dans son entièreté représente la maison d'édition 

j'ai créé une entité non demandée info programmation pour la pettre en 
attribut de liaison entre un festival et sa ville .

De mon point de vue un festival peut être organisé dans plusieurs villes différentes soyus le m^me nm 

j'ai pris le partie de différencier 3 type de personnes ( auteurs , employé et visiteur ) 
ce qui peut provoquer une redondance dansle cas ou un employé veut venir visiter sur son jour de congé ou 
si un auteur etst employé etc.

Merci de l'attention portée à monn travail.

Respectueusement,

Benjamin DOUCHET
Groupe 2


