TP2 - COLLE - DOUCHET

Exercice 1 ---

f) afin de contraintre la baignoire à la salle  de bain il nous faudrait modeliser 
les types de pièces en tant qu'entitée au lieu d'être des attributs de l'entitée pièce.

ainsi nous pourrions contraindre la relation "contient" avec un cardinalité entre 
baignoire et salle de bain.



Exercice 2 --- 

G) on peut facilemtn le mettre en place si au lieu de commander 
dans des catégories le client commande dans des points de vente directement.

cf Schema annexe fin de doc.